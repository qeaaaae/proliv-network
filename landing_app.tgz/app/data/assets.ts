import brandLogoUrl from '~/assets/images/brand/logo.svg'
import deFlagUrl from '~/assets/images/flags/de.svg'
import eeFlagUrl from '~/assets/images/flags/ee.svg'
import gbFlagUrl from '~/assets/images/flags/gb.svg'
import cryptobotLogoUrl from '~/assets/images/payments/cryptobot.svg'
import heleketLogoUrl from '~/assets/images/payments/heleket.svg'
import yookassaLogoUrl from '~/assets/images/payments/yookassa.svg'
import type { CountryCode } from '~/types/content'

export { brandLogoUrl }

export const flagUrls = {
  de: deFlagUrl,
  ee: eeFlagUrl,
  gb: gbFlagUrl
} satisfies Record<CountryCode, string>

export const paymentMarks = [
  { id: 'yookassa', src: yookassaLogoUrl, alt: 'ЮKassa', width: 92, height: 22 },
  { id: 'heleket', src: heleketLogoUrl, alt: 'Heleket', width: 26, height: 26 },
  { id: 'cryptobot', src: cryptobotLogoUrl, alt: 'CryptoBot', width: 35, height: 19 }
] as const
